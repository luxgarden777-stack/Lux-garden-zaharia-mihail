SITE ZAHARIA MIHAIL
Version basée sur la maquette approuvée.
Email: luxgarden777@gmail.com
Téléphone: 06 04 44 73 73
Zone: Alpes-Maritimes (06)

Ouvrir index.html pour tester le site.
Le formulaire ouvre la messagerie du téléphone/ordinateur via mailto.
Pour une mise en ligne, publier le contenu de ce dossier comme Static Site.
